<?php
/**
 * CLI migration runner.
 *
 *   php migrate.php run                         run pending migrations
 *   php migrate.php status                      show applied / pending
 *   php migrate.php rollback                    roll back the latest migration
 *   php migrate.php rollback-all                roll back everything (DROPS TABLES)
 *   php migrate.php refresh                     rollback-all, then run again (DROPS TABLES)
 *   php migrate.php create-migration NAME       e.g. create_orders_table
 *
 * It feeds the matching /migrate, /status ... route to the framework, so the flow is
 * CLI -> Controller -> Route -> Migration library -> Database (same as the lab).
 * Database credentials come from .env or real environment variables.
 */
if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit('CLI only');
}

$routes = [
    'run'              => 'migrate',
    'create-migration' => 'create-migration',
    'rollback'         => 'rollback',
    'rollback-all'     => 'rollback-all',
    'refresh'          => 'refresh',
    'status'           => 'status',
];

$action = $argv[1] ?? 'run';
$name   = $argv[2] ?? null;

if (!isset($routes[$action])) {
    fwrite(STDERR, "Unknown action \"{$action}\". Available: " . implode(', ', array_keys($routes)) . PHP_EOL);
    exit(1);
}

$route = $routes[$action];
if ($action === 'create-migration') {
    if (!$name) {
        fwrite(STDERR, "Migration name is required. Example: php migrate.php create-migration create_orders_table" . PHP_EOL);
        exit(1);
    }
    $route .= '/' . $name;
}

if (in_array($action, ['rollback-all', 'refresh'], true)) {
    fwrite(STDERR, "Warning: '{$action}' drops tables. Use it on a development database only." . PHP_EOL);
}

chdir(__DIR__);
$_SERVER['SCRIPT_NAME']    = '/index.php';
$_SERVER['PHP_SELF']       = '/index.php/' . $route;
$_SERVER['REQUEST_METHOD'] = 'GET';
$_SERVER['REQUEST_URI']    = '/' . $route;
$_SERVER['HTTP_HOST']      = 'localhost';
$_SERVER['REMOTE_ADDR']    = '127.0.0.1';

// The library prints HTML line breaks; turn them into real newlines for the terminal
ob_start(function ($buffer) {
    return preg_replace('#<br\s*/?>#i', PHP_EOL, $buffer);
});

require __DIR__ . '/index.php';
