<?php

class Create_users_table {

    private $_lava;

    public function __construct()
    {
        $this->_lava =& lava_instance();
    }

    public function up()
    {
        $this->_lava->db->raw("
            CREATE TABLE IF NOT EXISTS users (
                id INT NOT NULL AUTO_INCREMENT,
                username VARCHAR(50) NOT NULL,
                email VARCHAR(100) NOT NULL,
                password VARCHAR(255) NOT NULL,
                role VARCHAR(20) NOT NULL DEFAULT 'user',
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uq_users_username (username),
                UNIQUE KEY uq_users_email (email)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");
        echo "Table 'users' created successfully.<br>";
    }

    public function down()
    {
        $this->_lava->db->raw('DROP TABLE IF EXISTS users');
        echo "Table 'users' dropped successfully.<br>";
    }
}
