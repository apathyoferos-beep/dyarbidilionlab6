<?php

class Create_refresh_tokens_table {

    private $_lava;

    public function __construct()
    {
        $this->_lava =& lava_instance();
    }

    public function up()
    {
        // token holds the encrypted refresh token written by the Api library.
        // jti is optional: newer versions of the Api library fill it, older ones leave it NULL.
        $this->_lava->db->raw("
            CREATE TABLE IF NOT EXISTS refresh_tokens (
                id INT NOT NULL AUTO_INCREMENT,
                user_id INT NOT NULL,
                token TEXT NOT NULL,
                expires_at DATETIME NOT NULL,
                jti VARCHAR(64) NULL,
                PRIMARY KEY (id),
                KEY idx_refresh_tokens_user (user_id),
                KEY idx_refresh_tokens_token (token(191)),
                CONSTRAINT fk_refresh_tokens_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");
        echo "Table 'refresh_tokens' created successfully.<br>";
    }

    public function down()
    {
        $this->_lava->db->raw('DROP TABLE IF EXISTS refresh_tokens');
        echo "Table 'refresh_tokens' dropped successfully.<br>";
    }
}
