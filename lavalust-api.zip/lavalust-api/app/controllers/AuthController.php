<?php
defined('PREVENT_DIRECT_ACCESS') OR exit('No direct script access allowed');

/**
 * Controller: AuthController
 *
 * POST /auth/register   create an account
 * POST /auth/login      returns access_token + refresh_token
 * POST /auth/refresh    rotates the token pair
 * POST /auth/logout     revokes the refresh token
 * GET  /auth/me         current user (needs Bearer token)
 */
class AuthController extends Controller
{
    public function __construct()
    {
        parent::__construct();
        // Loading the library also sends the CORS headers and answers OPTIONS preflight requests
        $this->call->library('api');
    }

    public function register()
    {
        $this->api->require_method('POST');
        $input = $this->api->body();

        $username = trim((string) ($input['username'] ?? ''));
        $email    = strtolower(trim((string) ($input['email'] ?? '')));
        $password = (string) ($input['password'] ?? '');

        $errors = [];
        if (!preg_match('/^[A-Za-z0-9_]{3,50}$/', $username)) {
            $errors['username'] = 'Username must be 3-50 characters: letters, numbers and underscores only.';
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 100) {
            $errors['email'] = 'A valid email address (max 100 characters) is required.';
        }
        if (strlen($password) < 8 || strlen($password) > 72) {
            $errors['password'] = 'Password must be 8-72 characters.';
        }
        if ($errors) {
            $this->api->respond(['error' => 'Validation failed', 'errors' => $errors], 422);
        }

        $stmt = $this->db->raw('SELECT id FROM users WHERE username = ? OR email = ? LIMIT 1', [$username, $email]);
        if ($stmt->fetch(PDO::FETCH_ASSOC)) {
            $this->api->respond(['error' => 'Username or email is already registered.'], 409);
        }

        $id = $this->db->table('users')->insert([
            'username' => $username,
            'email'    => $email,
            'password' => password_hash($password, PASSWORD_BCRYPT),
            'role'     => 'user',
        ]);

        $this->api->respond([
            'message' => 'Account created. You can now log in.',
            'user'    => ['id' => (int) $id, 'username' => $username, 'email' => $email, 'role' => 'user'],
        ], 201);
    }

    public function login()
    {
        $this->api->require_method('POST');
        $input = $this->api->body();

        $login    = trim((string) ($input['username'] ?? ($input['email'] ?? '')));
        $password = (string) ($input['password'] ?? '');

        if ($login === '' || $password === '') {
            $this->api->respond_error('Username and password are required.', 422);
        }

        $stmt = $this->db->raw(
            'SELECT id, username, email, password, role FROM users WHERE username = ? OR email = ? LIMIT 1',
            [$login, strtolower($login)]
        );
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        // Same message for "unknown user" and "wrong password" so accounts cannot be probed
        if (!$user || !password_verify($password, $user['password'])) {
            $this->api->respond_error('Invalid credentials', 401);
        }

        $tokens = $this->api->issue_tokens([
            'id'   => (int) $user['id'],
            'role' => $user['role'],
        ]);

        $this->api->respond(array_merge(['token_type' => 'Bearer'], $tokens, [
            'user' => [
                'id'       => (int) $user['id'],
                'username' => $user['username'],
                'email'    => $user['email'],
                'role'     => $user['role'],
            ],
        ]));
    }

    public function refresh()
    {
        $this->api->require_method('POST');
        $input = $this->api->body();

        $token = (string) ($input['refresh_token'] ?? '');
        if ($token === '') {
            $this->api->respond_error('refresh_token is required.', 422);
        }

        // Validates the token, revokes it, issues a new pair and responds
        $this->api->refresh_access_token($token);
    }

    public function logout()
    {
        $this->api->require_method('POST');
        $input = $this->api->body();

        $token = (string) ($input['refresh_token'] ?? '');
        if ($token !== '') {
            $this->api->revoke_refresh_token($token);
        }

        $this->api->respond(['message' => 'Logged out']);
    }

    public function me()
    {
        $this->api->require_method('GET');

        if (!$this->api->get_bearer_token()) {
            $this->api->respond_error('Authentication required', 401);
        }
        $auth = $this->api->require_jwt();
        if (($auth['type'] ?? '') === 'refresh') {
            $this->api->respond_error('Unauthorized', 401);
        }

        $stmt = $this->db->raw('SELECT id, username, email, role, created_at FROM users WHERE id = ?', [$auth['sub']]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$user) {
            $this->api->respond_error('User not found', 404);
        }
        $this->api->respond(['user' => $user]);
    }
}
