<?php
defined('PREVENT_DIRECT_ACCESS') OR exit('No direct script access allowed');

/**
 * Controller: ProductController
 *
 * Every endpoint requires an access token:  Authorization: Bearer <access_token>
 *
 * GET    /products          list (optional ?q=search)
 * GET    /products/{id}     one product
 * POST   /products          create
 * PUT    /products/{id}     replace (all fields required)
 * PATCH  /products/{id}     partial update
 * DELETE /products/{id}     delete
 */
class ProductController extends Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->call->library('api');
    }

    // ---------------------------------------------------------------- helpers

    /**
     * Stop with 401 unless the request carries a valid ACCESS token.
     * (A refresh token is also a valid JWT, so it is rejected explicitly.)
     */
    private function authenticate()
    {
        if (!$this->api->get_bearer_token()) {
            $this->api->respond_error('Authentication required', 401);
        }
        $auth = $this->api->require_jwt();
        if (($auth['type'] ?? '') === 'refresh') {
            $this->api->respond_error('Unauthorized', 401);
        }
        return $auth;
    }

    private function find($id)
    {
        if (!ctype_digit((string) $id)) {
            $this->api->respond_error('Product not found', 404);
        }
        $product = $this->db->table('products')->where('id', (int) $id)->get();
        if (!$product) {
            $this->api->respond_error('Product not found', 404);
        }
        return $product;
    }

    /**
     * Validate request data. With $partial = true only the supplied fields are checked.
     */
    private function validated(array $input, $partial = false)
    {
        $data = [];
        $errors = [];

        if (!$partial || array_key_exists('product_name', $input)) {
            $name = is_scalar($input['product_name'] ?? null) ? trim((string) $input['product_name']) : '';
            if ($name === '' || mb_strlen($name) > 100) {
                $errors['product_name'] = 'Product name is required (max 100 characters).';
            } else {
                $data['product_name'] = $name;
            }
        }

        if (!$partial || array_key_exists('description', $input)) {
            $description = $input['description'] ?? '';
            if (!is_scalar($description) && $description !== null) {
                $errors['description'] = 'Description must be text.';
            } else {
                $data['description'] = trim((string) $description);
            }
        }

        if (!$partial || array_key_exists('price', $input)) {
            $price = $input['price'] ?? null;
            if (!is_scalar($price) || !is_numeric($price) || (float) $price < 0 || (float) $price > 99999999.99) {
                $errors['price'] = 'Price must be a number between 0 and 99,999,999.99.';
            } else {
                $data['price'] = number_format((float) $price, 2, '.', '');
            }
        }

        if (!$partial || array_key_exists('quantity', $input)) {
            $quantity = is_scalar($input['quantity'] ?? null)
                ? filter_var($input['quantity'], FILTER_VALIDATE_INT, ['options' => ['min_range' => 0, 'max_range' => 2147483647]])
                : false;
            if ($quantity === false) {
                $errors['quantity'] = 'Quantity must be a whole number (0 or more).';
            } else {
                $data['quantity'] = $quantity;
            }
        }

        if ($errors) {
            $this->api->respond(['error' => 'Validation failed', 'errors' => $errors], 422);
        }
        if ($partial && !$data) {
            $this->api->respond_error('No valid fields to update.', 422);
        }
        return $data;
    }

    // ---------------------------------------------------------------- actions

    public function index()
    {
        $this->api->require_method('GET');
        $this->authenticate();

        $query = $this->db->table('products');
        $q = trim((string) ($this->api->get_query_params()['q'] ?? ''));
        if ($q !== '') {
            $query->like('product_name', '%' . $q . '%');
        }
        $products = $query->order_by('id', 'DESC')->get_all();

        $this->api->respond(['data' => $products, 'count' => count($products)]);
    }

    public function show($id)
    {
        $this->api->require_method('GET');
        $this->authenticate();

        $this->api->respond(['data' => $this->find($id)]);
    }

    public function store()
    {
        $this->api->require_method('POST');
        $this->authenticate();

        $data = $this->validated($this->api->body());
        $id = $this->db->table('products')->insert($data);

        $this->api->respond([
            'message' => 'Product created',
            'data'    => $this->find($id),
        ], 201);
    }

    public function update($id)
    {
        $this->api->require_method('PUT');
        $this->authenticate();
        $this->find($id);

        $data = $this->validated($this->api->body());
        $this->db->table('products')->where('id', (int) $id)->update($data);

        $this->api->respond(['message' => 'Product updated', 'data' => $this->find($id)]);
    }

    public function patch($id)
    {
        $this->api->require_method('PATCH');
        $this->authenticate();
        $this->find($id);

        $data = $this->validated($this->api->body(), true);
        $this->db->table('products')->where('id', (int) $id)->update($data);

        $this->api->respond(['message' => 'Product updated', 'data' => $this->find($id)]);
    }

    public function destroy($id)
    {
        $this->api->require_method('DELETE');
        $this->authenticate();
        $this->find($id);

        $this->db->table('products')->where('id', (int) $id)->delete();

        $this->api->respond(['message' => 'Product deleted']);
    }
}
