<?php
defined('PREVENT_DIRECT_ACCESS') OR exit('No direct script access allowed');

/**
 * Controller: HomeController
 *
 * Simple health-check endpoint (GET /).
 */
class HomeController extends Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->call->library('api');
    }

    public function index()
    {
        $this->api->respond([
            'name'    => 'Product Management API',
            'status'  => 'ok',
            'version' => '1.0.0',
        ]);
    }
}
