<?php
defined('PREVENT_DIRECT_ACCESS') OR exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| API library settings
|--------------------------------------------------------------------------
|
| Secrets are read from environment variables so they never live in GitHub.
| Generate each secret with:  php -r "echo bin2hex(random_bytes(32));"
|
*/
$config['api_helper_enabled'] = TRUE;

// Access token lifetime (seconds) - 15 minutes
$config['payload_token_expiration'] = 900;

// Refresh token lifetime (seconds) - 7 days
$config['refresh_token_expiration'] = 604800;

// Signing keys (use 32+ characters). The fallbacks below are for local development only.
$config['jwt_secret']        = getenv('JWT_SECRET')        ?: 'dev-only-jwt-secret-change-me-0123456789';
$config['refresh_token_key'] = getenv('REFRESH_TOKEN_KEY') ?: 'dev-only-refresh-key-change-me-0123456789';

// JWT claims (used by newer versions of the Api library; ignored by older ones)
$config['jwt_issuer']   = getenv('APP_URL') ?: 'http://localhost:8080';
$config['jwt_audience'] = getenv('APP_URL') ?: 'http://localhost:8080';

// CORS: set FRONTEND_ORIGIN to your React app's URL once deployed (e.g. https://my-app.onrender.com)
$config['allow_origin'] = getenv('FRONTEND_ORIGIN') ?: '*';

// Table used to store hashed refresh tokens
$config['refresh_token_table'] = 'refresh_tokens';

// Rate limiting (used by newer versions of the Api library)
$config['rate_limit_enabled']  = TRUE;
$config['rate_limit_requests'] = 120;
$config['rate_limit_seconds']  = 60;

// Refuse to run in production with the development fallback secrets
if (strtolower((string) getenv('APP_ENV')) === 'production'
    && (!getenv('JWT_SECRET') || !getenv('REFRESH_TOKEN_KEY')
        || strlen(getenv('JWT_SECRET')) < 32 || strlen(getenv('REFRESH_TOKEN_KEY')) < 32)) {
    http_response_code(500);
    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode(['error' => 'Server misconfigured: set JWT_SECRET and REFRESH_TOKEN_KEY (32+ characters each).']);
    exit;
}
