# Product Management API (LavaLust)

REST API for Laboratory Exercise No. 6, built on the LavaLust framework. It exposes token-protected
CRUD endpoints for `products`, with accounts and refresh tokens handled by LavaLust's `Api` library.

```
React app --HTTP/JSON--> LavaLust API (Render) --TLS--> Aiven MySQL
```

## Endpoints

| Method | Path | Auth | Purpose |
| --- | --- | --- | --- |
| GET | `/` | no | health check |
| POST | `/auth/register` | no | create account (`username`, `email`, `password`) |
| POST | `/auth/login` | no | returns `access_token` (15 min) and `refresh_token` (7 days) |
| POST | `/auth/refresh` | no | swap a refresh token for a new pair (old one is revoked) |
| POST | `/auth/logout` | no | revoke the refresh token |
| GET | `/auth/me` | Bearer | current user |
| GET | `/products` | Bearer | list products (`?q=` searches by name) |
| GET | `/products/{id}` | Bearer | one product |
| POST | `/products` | Bearer | create |
| PUT | `/products/{id}` | Bearer | replace (all fields required) |
| PATCH | `/products/{id}` | Bearer | partial update |
| DELETE | `/products/{id}` | Bearer | delete |

Send protected requests with `Authorization: Bearer <access_token>`.
Product body: `{"product_name": "Keyboard", "description": "...", "price": 89.5, "quantity": 12}`.

> The Api library's CORS header only lists `GET, POST, PUT, DELETE, OPTIONS`, so browser code should
> use **PUT** (not PATCH) for updates. PATCH still works from Postman or curl.

## Run it locally

Requirements: PHP 8.1+ with `pdo_mysql`, and a MySQL/MariaDB database.

```bash
cp .env.example .env          # then edit DB_* and generate JWT_SECRET / REFRESH_TOKEN_KEY
php migrate.php run           # creates migrations, users, refresh_tokens, products
```

The API needs the `index.php/…` URL rewrite, so serve it with Apache/XAMPP (point the document root
at this folder; `.htaccess` is included) or with Docker:

```bash
docker build -t product-api .
docker run --rm -p 8080:10000 --env-file .env product-api
```

## Migrations

`php migrate.php <action>` runs the same routes as the lab (`/migrate`, `/status`, …) without needing a browser:

| Command | Effect |
| --- | --- |
| `php migrate.php run` | run pending migrations |
| `php migrate.php status` | show applied / pending |
| `php migrate.php rollback` | undo the latest migration |
| `php migrate.php rollback-all` | undo everything (drops tables) |
| `php migrate.php refresh` | rollback-all, then run again (drops tables) |
| `php migrate.php create-migration create_orders_table` | new empty migration file |

Migration routes are **not** registered on the deployed API unless `MIGRATION_ENABLED=true`.
Run migrations from your own computer against Aiven (set the Aiven values in `.env`).

Changes made to the framework's `scheme/` folder:
- `libraries/Migration.php` creates the `migrations` table when missing and adds `rollback_all`, `refresh` and `status`.
- `database/Database.php` accepts `ssl` / `ssl_ca` settings so PDO can connect to Aiven over TLS.

## Aiven MySQL setup

1. In Aiven, create a MySQL service (the free plan is fine) and wait until it is **Running**.
2. On the service Overview page copy **Host, Port, User, Password, Database name** into `.env`
   (`DB_HOST`, `DB_PORT`, `DB_USER`, `DB_PASSWORD`, `DB_NAME`) and set `DB_SSL=true`.
3. Download the **CA certificate**, save it as `certs/aiven-ca.pem` and set `DB_SSL_CA=certs/aiven-ca.pem`.
4. If the service has an IP allow-list, allow your IP (and for Render, allow all addresses or Render's outbound IPs).
5. Run `php migrate.php run`, then check the tables in your DB tool for the screenshot.

## Deploy to Render

1. Push this folder to its own GitHub repository (`.env` and `certs/*.pem` are git-ignored).
2. Render dashboard → **New → Web Service** → pick the repo → **Language: Docker**
   (or **New → Blueprint** to use `render.yaml`).
3. Add environment variables:

| Key | Value |
| --- | --- |
| `APP_ENV` | `production` |
| `DB_HOST`, `DB_PORT`, `DB_USER`, `DB_PASSWORD`, `DB_NAME` | from Aiven |
| `DB_SSL` | `true` |
| `DB_SSL_CA_PEM` | the full text of the Aiven CA certificate |
| `JWT_SECRET`, `REFRESH_TOKEN_KEY` | two different random strings, 32+ characters |
| `FRONTEND_ORIGIN` | your React app URL, e.g. `https://my-products.onrender.com` (no trailing slash) |
| `APP_URL` | this API's own Render URL |

4. Deploy, then open `https://<your-service>.onrender.com/` – you should see `{"status":"ok", ...}`.

In `production` mode the API refuses to start without strong `JWT_SECRET` / `REFRESH_TOKEN_KEY` values.
Free Render services sleep when idle, so the first request after a pause can take about a minute.

## Quick test with curl

```bash
curl -X POST $API/auth/register -H 'Content-Type: application/json' \
  -d '{"username":"ana","email":"ana@example.com","password":"password123"}'
curl -X POST $API/auth/login -H 'Content-Type: application/json' \
  -d '{"username":"ana","password":"password123"}'
curl $API/products -H "Authorization: Bearer $ACCESS_TOKEN"
```
